//
//  OnBordingView.swift
//  Career-Pilot-iOS
//
//  Created by Mohamed Magdy on 15/07/2026.
//

import SwiftUI

struct OnBordingView: View {
    @StateObject var vm: OnBordingViewModel = DIContainer.shared.container.resolve(OnBordingViewModel.self)!
    
    var body: some View {
        VStack(alignment: .center, spacing: 14){
            //Top Part
            OnBordingTopPart(vm: vm)
            Spacer()
            
            //OnBording Content
            switch vm.screenState{
            case.idel:
                OnBordingIdelState(vm: vm)
            case.loading:
                ProgressView()
            case.error(let error):
                OnBoardingErrorState(vm: vm, errorMessage: error.description)
            }
            
            //Bottom Part
            Spacer()
            CustomButton(isButtonEnabeld: vm.isButtonEnabeld, buttonTitle: vm.buttonTitle){
                print("Clicked")
                vm.navToNext()
            }
        }
        .navigationDestination(isPresented: $vm.navToHomeScreen){
            MainTabBarView()
        }
        .task {
            vm.onApper()
        }
    }
}

private struct OnBordingTopPart: View {
    @StateObject var vm: OnBordingViewModel
    
    var body: some View {
        HStack(spacing: 8){
            VStack{
                if vm.currentView.rawValue != 0 {
                    BackButton()
                        .onTapGesture {
                            vm.backByStep()
                        }
                }
                drawDotts
            }
            
            Spacer()
            
            Text("\(vm.currentView.rawValue + 1) of \(OnBordingViews.allCases.count)")
                .foregroundColor(.gray400)
        }
        .padding()
    }
    
    //MARK: the above dotts to define the numbers of the completed views
    private var drawDotts: some View{
        HStack(spacing: 4){
            ForEach(0..<OnBordingViews.allCases.count, id: \.self){ index in
                RoundedRectangle(cornerRadius: 25)
                    .frame(width: vm.isScreenIncludedToDrawAColor(index: index) ? 25 : 10 ,
                           height: 10)
                    .foregroundColor(vm.isScreenIncludedToDrawAColor(index: index) ? .activeColour : .gray400.opacity(0.5))
                
            }
        }
    }
}

struct BackButton: View{
    var body: some View{
        HStack(spacing: 8){
            Image(systemName: "arrow.left")
            Text("Back")
        }
    }
}

//Preview
struct OnBordingView_Previews: PreviewProvider {
    static var previews: some View {
        OnBordingView()
    }
}
